from django import forms
from .models import report


class repform(forms.ModelForm):
    class Meta:
        model=report

        fields=['Location','Incident_Description','Event_date','Time','Incident_Location','Initial_Severity','Suspected_Cause','Immediate_Action_Taken','Reported_By','Sub_Incident_Types']
        widgets = {
            'Reported_By': forms.TextInput(attrs={
                'class':'form-control',
                'placeholder': 'Enter Name'
            }),
            'Event_date':forms.DateInput(attrs={
                'class': 'form-control',
                'placeholder':'DD/MM/YYYY'
            }),
            'Time':forms.TimeInput(attrs={
                'class': 'form-control',
                'placeholder':'HH:MM:SS'
            }),
            'Incident_Description': forms.Textarea(attrs={'class':'form-control','id':"exampleInputName2",'rows': 2,'placeholder':'Write Incident Description.....',}),
            'Location':forms.Select(attrs={
                'class':'form-control',

            }),
            'Incident_Location':forms.Textarea(attrs={'class':'form-control','rows':2,'placeholder':'Write Incident Location.....'}),
            'Initial_Severity':forms.Select(attrs={
                'class':'form-control'
            }),
            'Suspected_Cause':forms.Textarea(attrs={'class':'form-control','rows':2,'placeholder':'Write Suspected Cause.....'}),
            'Immediate_Action_Taken':forms.Textarea(attrs={'class':'form-control','rows':2,'placeholder':'Write Imediate Action, that taken.....'}),
            'Sub_Incident_Types':forms.Select(attrs={
                'class':'form-control','placeholder':'--Choose Incident Type--'
            }),
        }