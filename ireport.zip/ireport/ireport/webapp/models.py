from django.db import models
from datetime import datetime
import datetime


# Create your models here.
class report(models.Model):
    loc = (('Corporate Office', "Corporate Office"), ('Head Post-office', "Head Post-office"),
           ('MG Chowrasta', "MG Chowrasta"))
    Location = models.CharField(max_length=20, choices=loc)
    Incident_Description = models.TextField(error_messages=None)
    Event_date = models.DateTimeField('Date')
    Time = models.TimeField('Time')
    Incident_Location = models.TextField(blank=True)
    sever = (('Normal', "Normal"), ('Moderate', "Moderate"), ('Serious', "Serious"))
    Initial_Severity = models.CharField(max_length=20, choices=sever)
    Suspected_Cause = models.TextField(blank=True)
    MY_CHOICES = (('Environmental Incident', "Environmental Incident"),
                  (' Injury Illness', " Injury Illness"),
                  ('Property Damage', "Property Damage"),
                  ('Vehicle Accident', "Vehicle Accident"),)
    Sub_Incident_Types = models.CharField(max_length=50,choices=MY_CHOICES)
    Immediate_Action_Taken = models.TextField(blank=True)
    Reported_By = models.CharField(max_length=15)

    def __str__(self):
        return self.Location
