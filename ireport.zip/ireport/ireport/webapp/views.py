from django.shortcuts import render
from django.http import HttpResponseRedirect
from .forms import repform


def frm(request):
    if request.method == "POST":
        forma = repform(request.POST)
        if forma.is_valid():
            forma.save(commit=True)
            return HttpResponseRedirect('/thankyou')
    else:
        forma = repform()
    return render(request, 'formm.html', {'forma': forma})


def thank(request):
    return render(request, 'Thankyou.html')


