from django.contrib import admin
from .models import report
# Register your models here.
class repadmin(admin.ModelAdmin):
    list_display = ('Location','Initial_Severity','Reported_By')
admin.site.register(report,repadmin)